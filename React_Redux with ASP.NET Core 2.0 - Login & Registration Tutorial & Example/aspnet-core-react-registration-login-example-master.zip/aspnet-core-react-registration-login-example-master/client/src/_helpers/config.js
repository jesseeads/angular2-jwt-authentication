export const config = {
    apiUrl: 'http://localhost:5000'
};