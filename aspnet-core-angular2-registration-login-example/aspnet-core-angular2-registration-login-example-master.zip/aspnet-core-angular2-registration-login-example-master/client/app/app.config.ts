﻿export class AppConfig {
    public readonly apiUrl = 'http://localhost:5000';
};